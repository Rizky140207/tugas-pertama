<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo e(url('/')); ?>">MyStore</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item"><a class="nav-link active" href="<?php echo e(url('/')); ?>">Home</a></li>
                 <?php if(Route::has('login')): ?>
                    <?php if(auth()->guard()->check()): ?>
                      <li class="nav-item">
                    <a class="btn btn-primary btn-sm ms-3" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                </li>
                    <?php else: ?>
                         <li class="nav-item">
                    <a class="btn btn-primary btn-sm ms-3" href="<?php echo e(route('login')); ?>">Log in</a>
                </li>

                        <?php if(Route::has('register')): ?>
                             <li class="nav-item">
                    <a class="btn btn-primary btn-sm ms-3" href="<?php echo e(route('register')); ?>">Register</a>
                </li>
                        <?php endif; ?>
                    <?php endif; ?>
            <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\laragon\www\tugas-pertama\tugas\resources\views/navbar.blade.php ENDPATH**/ ?>