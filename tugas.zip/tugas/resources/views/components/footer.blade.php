<footer class="bg-dark text-white text-center py-4">
    <p class="mb-1 fw-semibold">MyStore</p>
    <small>© 2026 E-Commerce Modern • All rights reserved</small>
</footer>